/* $Id: atti_utils.h,v 1.1 2004/03/09 17:42:44 wib Exp $ */


#ifndef _atti_utils_h_
#define _atti_utils_h_

#define loop(A,B) for(A=0;A<B;A++)
#define loop3(A) for (A=0; A<3; A++)


#include "GRACEdefs.h" /* for typedef double real; */

#endif
