#! /bin/csh -f

# $Id: MakeLinkTime,v 1.1 2009/06/06 22:46:55 glk Exp glk $

echo '# include <stdio.h>'
echo '# include <string.h>'
echo '# include <inttypes.h>'
echo ' '
echo 'void LinkTime(char *label)'
echo '{' 
echo ' int8_t  tag[] = "@(#) '`date +%Y-%m-%d%t%R:%S`' '`whoami`' ' `uname -n`'";'
echo ' strcpy(label,tag);'
echo '}'

exit(0)
