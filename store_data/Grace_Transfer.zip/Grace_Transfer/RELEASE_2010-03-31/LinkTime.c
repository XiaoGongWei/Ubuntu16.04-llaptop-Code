# include <stdio.h>
# include <string.h>
# include <inttypes.h>
 
void LinkTime(char *label)
{
 int8_t  tag[] = "@(#) 2018-11-14 22:19:25 root  david";
 strcpy(label,tag);
}
