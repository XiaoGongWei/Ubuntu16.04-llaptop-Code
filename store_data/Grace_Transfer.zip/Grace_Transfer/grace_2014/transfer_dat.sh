#!/bin/bash
# ./gps1x2rnx.e -gps1x ./GPS1B_2017-10-31_A_02.dat  -rnx ./GPS1B_2017-10-31_A_02.rnx
./Bin2AsciiLevel1.e -binfile GNV1B_2014-03-15_A_02.dat  -ascfile GNV1B_2014-03-15_A_02.asc #-nohead -norec
