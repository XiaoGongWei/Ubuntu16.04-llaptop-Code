function [X,Y,Z]=BLH_XYZ(B,L,H,Cs)


N=Cs.A/sqrt(1.0-Cs.E2*sin(B)*sin(B));
X=(N+H)*cos(B)*cos(L);
Y=(N+H)*cos(B)*sin(L);
Z=(N*(1-Cs.E2)+H)*sin(B);