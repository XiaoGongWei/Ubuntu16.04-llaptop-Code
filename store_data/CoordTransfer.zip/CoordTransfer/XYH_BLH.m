function [B,L,H,Cs]=XYH_BLH(X,Y,H1,Cs)

Cs.A=Cs.A+Cs.H0;
C=Cs.A/sqrt(1-Cs.E2);

e2=Cs.E2;
e4=e2*e2;
e6=e2*e4;
e8=e4*e4;
e10=e2*e8;

Ag=1+(3/4)*e2+(45/64)*e4+(175/256)*e6+(11025/16384)*e8+(43659/65536)*e10;
Bg=  (3/4)*e2+(15/16)*e4+(525/512)*e6+  (2205/2048)*e8+(72765/65536)*e10;
Cg=           (15/64)*e4+(105/256)*e6+  (2205/4096)*e8+(10395/16384)*e10;
Dg=                       (35/512)*e6+   (315/2048)*e8+(31185/13072)*e10;
%Eg=                                     (315/16384)*e8+ (3465/65536)*e10;
%Fg=                                                      (693/13072)*e10;

Alpha  =        Ag*Cs.A*(1-e2);
Beta   = -(1/2)*Bg*Cs.A*(1-e2);
Gamma  =  (1/4)*Cg*Cs.A*(1-e2);
Delta  = -(1/6)*Dg*Cs.A*(1-e2);
%Epsilon=  (1/8)*Eg*Cs.A*(1-e2);
%Zeta   =-(1/10)*Fg*Cs.A*(1-e2);

beta =zeros(1,5);
gamma=zeros(1,5);
delta=zeros(1,5);
beta(1) =-Beta/Alpha;
gamma(1)=-Gamma/Alpha;
delta(1)=-Delta/Alpha;

for i=1:4
    beta(i+1) =beta(1)+beta(1)*gamma(i)-2.0*gamma(1)*beta(i)-3.0*beta(1)*beta(i)*beta(i)/2.0;
    gamma(i+1)=gamma(1)+beta(1)*beta(i);
    delta(i+1)=delta(1)+beta(1)*gamma(i)+2.0*gamma(1)*beta(i)+beta(1)*beta(i)*beta(i)/2.0;
end;

K1=2*beta(end)+4*gamma(end)+6*delta(end);
K2=-8*gamma(end)-32*delta(end);
K3=32*delta(end);

Y=(Y-Cs.Y0*1000)/Cs.UTM;
X=(X-Cs.X0*1000)/Cs.UTM;

Bf=X/Alpha;
Bf=Bf+cos(Bf)*(K1*sin(Bf)+K2*(sin(Bf))^3+K3*(sin(Bf))^5);

Etaf=e2/(1-e2)*cos(Bf)*cos(Bf);
Vf2=1+e2/(1-e2)*cos(Bf)*cos(Bf);
Nf=C/sqrt(Vf2);
M1=Y/Nf;
tf=tan(Bf);
Mb=(Y/Nf)*(Y/Nf);

B=Bf-(1/2)*Vf2*tf*Mb+(1/24)*(5+3*tf^2+Etaf-9*Etaf*tf^2)*Vf2*tf*(Mb^2)-(1/720)*(61+90*(tf^2)+45*(tf^4))*Vf2*tf*(Mb^3);
l=(1/cos(Bf))*M1-(1/6)*(1+2*tf^2+Etaf)*(1/cos(Bf))*(M1^3)+(1/120)*(5+28*tf^2+24*tf^4+6*Etaf+8*Etaf*tf^2)*(1/cos(Bf))*(Mb^2)*M1;

L=l+Cs.L0;
H=H1+Cs.DN;
[XX,YY,ZZ]=BLH_XYZ(B,L,H,Cs);
Cs.A=Cs.A-Cs.H0;
[B,L,H]=XYZ_BLH(XX,YY,ZZ,Cs);
H=H1+Cs.DN;
