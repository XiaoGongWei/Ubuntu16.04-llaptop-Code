function plot_ppp_pos( ppp_pos, true_pos )
%PLOT_PPP_POS Summary of this function goes here
%   Detailed explanation goes here



data_len = length(ppp_pos);
diff_pos_NEU = zeros(data_len, 3);
for i = 1:data_len
    diff_pos_NEU(i,:) = XYZ_NEU(ppp_pos(i, :), ppp_pos(i, :) - true_pos);
end

h2 = figure;
hold on
plot(diff_pos_NEU,'.');
legend('dN','dE','dU')

end

