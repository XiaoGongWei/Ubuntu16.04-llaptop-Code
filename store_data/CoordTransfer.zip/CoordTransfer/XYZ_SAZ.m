function [S,A,Z]=XYZ_SAZ(Xi,Yi,Zi,Xk,Yk,Zk,Cs)

R=zeros(3);
[Bi,Li,Hi]=XYZ_BLH(Xi,Yi,Zi,Cs);

R(1,1)=-sin(Bi)*cos(Li);
R(1,2)=-sin(Bi)*sin(Li);
R(1,3)= cos(Bi);

R(2,1)=-sin(Li);
R(2,2)=cos(Li);
R(2,3)=0;

R(3,1)=cos(Bi)*cos(Li);
R(3,2)=cos(Bi)*sin(Li);
R(3,3)=sin(Bi);

Dx=R(1,1)*(Xk-Xi)+R(1,2)*(Yk-Yi)+R(1,3)*(Zk-Zi);
Dy=R(2,1)*(Xk-Xi)+R(2,2)*(Yk-Yi)+R(2,3)*(Zk-Zi);
Dz=R(3,1)*(Xk-Xi)+R(3,2)*(Yk-Yi)+R(3,3)*(Zk-Zi);

S=sqrt(Dx*Dx+Dy*Dy+Dz*Dz);
A=Azimuth(Dx,Dy);
Z=pi/2-atan(Dz/sqrt(Dx*Dx+Dy*Dy));