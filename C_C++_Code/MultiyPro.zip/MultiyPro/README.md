
compile is not error,but if you run Debug,you while see "error while loading shared libraries".
so you can copy all the ".so .so.1.0.0" etc files int ../build-manupro-Qt-Debug/bin  to "/lib" and
 "/usr/lib" and run "sudo ldconfig". you can also add "/usr/local/lib" to you shared libraies.

Referance: https://www.cnblogs.com/codingmengmeng/p/7456539.html

