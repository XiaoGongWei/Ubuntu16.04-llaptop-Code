#ifndef SMALLBODY_GLOBAL_H
#define SMALLBODY_GLOBAL_H

#ifndef _WIN32
    #define SMALLBODYSHARED_EXPORT     __attribute__((visibility("default")))
    #define SMALLBODYSHARED_IMPORT     __attribute__((visibility("default")))
    #define SMALLBODYSHARED_HIDDEN     __attribute__((visibility("hidden")))
#elif
    #define SMALLBODYSHARED_EXPORT     __declspec(dllexport)
    #define SMALLBODYSHARED_IMPORT     __declspec(dllimport)
#endif


#endif // SMALLBODY_GLOBAL_H
