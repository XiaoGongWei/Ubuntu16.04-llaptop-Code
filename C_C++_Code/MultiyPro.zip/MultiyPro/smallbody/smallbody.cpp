#include "smallbody.h"


Smallbody::Smallbody()
{
    qDebug() << "Smallbody" << endl;
}
