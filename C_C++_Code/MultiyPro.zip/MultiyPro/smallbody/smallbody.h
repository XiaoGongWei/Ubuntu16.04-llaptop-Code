#ifndef SMALLBODY_H
#define SMALLBODY_H

#include "smallbody_global.h"

#include <QDebug>

class SMALLBODYSHARED_EXPORT Smallbody
{

public:
    Smallbody();
    void speak() {qDebug() << "i'm Smallbody a static libray." << endl;}
};

#endif // SMALLBODY_H
