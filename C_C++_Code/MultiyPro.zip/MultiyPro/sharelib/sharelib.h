#ifndef SHARELIB_H
#define SHARELIB_H

#include "sharelib_global.h"
#include <QDebug>

class SHARELIBSHARED_EXPORT Sharelib
{

public:
    Sharelib();
    void speak() {qDebug() << "i'm Sharelib a share libray." << endl;}
};

#endif // SHARELIB_H
