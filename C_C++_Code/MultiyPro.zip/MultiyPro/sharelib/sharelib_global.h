#ifndef SHARELIB_GLOBAL_H
#define SHARELIB_GLOBAL_H

#ifndef _WIN32
    #define SHARELIBSHARED_EXPORT     __attribute__((visibility("default")))
    #define SHARELIBSHARED_IMPORT     __attribute__((visibility("default")))
    #define SHARELIBSHARED_HIDDEN     __attribute__((visibility("hidden")))
#elif
    #define SHARELIBSHARED_EXPORT     __declspec(dllexport)
    #define SHARELIBSHARED_IMPORT     __declspec(dllimport)
#endif


#endif // SHARELIB_GLOBAL_H
