#include "sharelib.h"


Sharelib::Sharelib()
{
    qDebug() << "Sharelib" << endl;
}
